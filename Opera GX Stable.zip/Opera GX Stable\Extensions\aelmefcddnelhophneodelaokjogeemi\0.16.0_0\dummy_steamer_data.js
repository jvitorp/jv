export const DUMMY_STREAM_DATA = [
  {
    id: '0',
    name: '',
    iconUrl: '',
    followed_at: '2019-06-06T09:21:43Z',
    login: '',
    isLive: false,
    title: '',
    viewerCount: 0,
    gameTitle: 'game',
    gameImageUrl: '',
    dummy: true,
  },
];
