export const $ = (...args) => document.querySelector(...args);
